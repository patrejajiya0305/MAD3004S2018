//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground" //NSArray foundation class

var friends : [String]
friends = ["Ishav", "Param" , "Rinkudevi" , "LA Baburao"]

print("Friends : \(friends)")

for frnd in friends {
    print("Friends : \(frnd)") //one by one with iteration variable frnd
    
    
}

for itr in 0..<friends.count{  //as index starts from 0 so therefore one less -----range
    print("Friend \(friends[itr])")
}

for(index,value) in friends.enumerated(){   //tuple (index(starts from 0) and over it value)
    print("index : \(index) value : \(value)")
}

for frnd in friends [2...] {
    print("Friends : \(frnd)") // starts from index spefied abd assume last value or first value by itself or default
}
for frnd in friends [...1] {
    print("Friends : \(frnd)") // starts from index spefied abd assume last value or first value by itself or default
}
var numbers = Array(repeating : 1, count : 4) //contains 4 elements
print("Numbers : \(numbers)")


numbers[2] = 100
print("Numbers : \(numbers)") // at index specified value changes

// with let it will be fixed


//var more = Array (repeating : 0.0, count : 3)

//print("more : \(more)")

//var all = numbers + more
//print("All : \(all)") //more than one type of array (array conatining similar types can be executed)

var more = Array (repeating : 0, count : 3)

print("more : \(more)")

var all = numbers + more
print("All : \(all)") //OR will be executed


for (index, value) in all.enumerated(){
    print("index : \(index) value : \(value)")
}
    print (" val = \(all[3])")


var grocery = ["Eggs" , "Milk"]


grocery.append("Rice")

grocery += ["Juice" , "Sher aata"] // index - 0,1,2,3,4

grocery[1...3] = ["Butter " , " Snacks" , "Ice Cream"] //assigned the new items 
print("Grocery : \(grocery)")


