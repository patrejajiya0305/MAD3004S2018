//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var languages = Set<String> ()
languages.insert("Hindi")
languages.insert("Punjabi")
languages.insert("Gujrati")
languages.insert("English")
languages.insert("French")


if languages.isEmpty{
    print("No language")
    
}else{
    print("\(languages.count) languages :  \(languages)")
}

for lang in languages.sorted(){
    print("language : \(lang)")
}

let motherTongue : Set = ["Guj" , "Pun" , "Tel"]
print ( " mothertongue : \(motherTongue)")

print ("Union : \(languages.union(motherTongue).sorted())")
print ("Intersection : \(languages.intersection(motherTongue).sorted())")
print ("Subtracting : \(languages.subtracting(motherTongue).sorted())")

let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]

print("Subset : \(houseAnimals.isSubset(of: farmAnimals))")
print("Superset : \(farmAnimals.isSuperset(of: houseAnimals))")
print("Disjoint  \(farmAnimals.isDisjoint(with: cityAnimals))")

//Dictionary

var namesofInt = [Int : String]()
namesofInt[20] = "Twenty"
print ("value of key 20 \(namesofInt[20])")
namesofInt[2] = "Two"
print ("value of key 2 \(namesofInt[2])")

print("namesofInt contains \(namesofInt.count) items")

namesofInt = [:]
if namesofInt.isEmpty
{
    print("No items")
}
var HTTPErrorCode : [Int : String] = [400 : "Bad Request" , 402 : "Payment Required" , 404 : "Not Found" , 406 : "Not Acceptable"]


HTTPErrorCode[405] = " Method not allowed"

print("Error code : \(HTTPErrorCode)")

let old402 = HTTPErrorCode.updateValue("Reserved for Future use", forKey: 402)

print("Error Code : \(HTTPErrorCode)")


 let errMSG406 = HTTPErrorCode[406]

print("Error message for 406 \(errMSG406)")


if let errMSG403 = HTTPErrorCode[403] {

print("Error message for 403 \(errMSG403)")
}else{
    print (" No error code for 403")
}

//no value contains nil in dictionary


HTTPErrorCode[406] = nil
print("Error code List: \(HTTPErrorCode)") // key removed


if let removedValue = HTTPErrorCode.removeValue(forKey: 404){
    print("Removed Value : \(removedValue)")
}else{
    print("Error code 404 mot available")
}

for errorCode in HTTPErrorCode.keys{
    print("Error Code : \(errorCode)")
}

for errorMsg in HTTPErrorCode.values{
    print("Error Message : \(errorMsg)")
    
    
}

for(errorCode, errorMsg) in HTTPErrorCode {
    print("Error code : \(errorCode) --- Error msg : \(errorMsg)")
}

let errorcodeList = HTTPErrorCode.keys
print ("Error code list : \(errorcodeList)")


var flight = [String : AnyObject]()
flight["number"] = "AC043" as AnyObject
flight["duration"] = 14 as AnyObject
flight["cost"] = 1600.23 as AnyObject

print("Flight \(flight)")
    
    





