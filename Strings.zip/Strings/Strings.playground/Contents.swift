//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)

var greet = """
Hello frands,
How are u doing!
Cludy weather...
Boring class
Funny Friends
"""
print("\(greet)")

var new = """
How are you!
Take care
Class going on...
"""
print(new)

var num = """
67
89
45
31
"""
print(num)

let mood = "\u{1F496}" //code predefined
print(mood)

if mood.isEmpty {
    print("No mood")   //checking mood is empty else executing
}else{
    


greet += mood  //Adding two
print(greet)
}

var team = String() // A class -- EMPTY STRING
team = "Croatia"
print(team)

for i in team{ //no need to refer index , i is iteration var it will read char by char
    print(i)
}

var initial : Character = "J" // character class datatype (String or char surrounded by char)
team.append(initial)  //appending - adding


print(team)

team.append("Go Go Go")
print (team) //Appendind strings and cHAR

print("Length of team : ", team.count) //count for counting length of string(counting spaces as well)

//print("Start Index of team : \(team.startIndex)") wound not work (although index starts from zero)

print("Start Index of team : \(team[team.startIndex])") //start index - first char starts with 0 - INDEX OBJECT
print("End Index of team : \(team.endIndex)") //CHAR AFTER LAST CHAR
//print("End Index of team : \(team[team.endIndex])") it does not refer to last char but after that like in croatia it will refer to 7th place so it wound not work anyway (end index wont work))

print("last character of team : \(team[team.index(before: team.endIndex)])") //CHAR BEFORE WHATEVER INDEX SPECIFIED

print("some character : \(team[team.index(after: team.startIndex)])") //after and before methods used for founding indexes // CHAR AFTER WHATEVER INDEX SPECIFIED

print("4th character :\(team[team.index(team.startIndex, offsetBy: 3)])") //starting from 0 OFFSET - PARTICULAR INDEX

print("6th character :\(team[team.index(team.endIndex, offsetBy: -5)])") //g starting from end index from last

var idx = team.index(team.endIndex, offsetBy: -5)
print("\(team[idx])")

for index in greet.indices {  //greet.indices - method (EACH SINGLE INDEX ) // COLLECTION OF ALL; INDEXES
    print("\(greet[index])" , terminator: "_") // after each of the charater it will put underscore
}
//for () in team.enumerated(){      //to get index and value at that index - this can be done by using tuple ---------wont work
    

print()
for(index,value) in team.enumerated(){
    print("Index : \(index) --- Value: \(value)")   //TUPLE RETURN (INDEX OF CHAR, LITERAL VALUE OF CHAR)
}


team.insert("!" , at: team.endIndex) // at is the label
print(team)

//CroatiaJGo Go Go!


//team.insert(" win it..", at: team.endIndex)- wont work


team.insert(contentsOf: " Win it.." , at: team.endIndex) // INSERTION
// CroatiaJ Go go Go! Win it..
print(team)

/*var idx1 = team.index(of: "J")
print("idx1 :(idx)")
print(team)*/

var idx1 = team.index(of: "J") ?? //if char not available in string use ??
team.endIndex
print("idx1 :\(idx1)")
print(team)

team.remove(at: idx1)
//Croatia Go Go Go ! Win it...

print(team)

var idxG = team.index(of : "G") ?? // IF CHAR VAILABLE THEN RETURN THE INDEX AND IF NOT (??) THEN END INDEX
team.endIndex

//team.removeSubrange(team.startIndex...idxG)
//print(team)

team.removeSubrange(team.startIndex..<idxG)
print(team)

var idxI = team.index(of: "t") ??   //?? - if not available then
team.endIndex
var idxW = team.index(of: "W") ??
team.startIndex
var win = team[idxW..<idx1]
print("\(win)")
//Win i

//var idxLast = win.indexwin.endIndex]
//win = win[win.startIndex...idxLast]




print(team.uppercased())

//GO GO GO! WIN IT..
team.lowercased()


print("\(team.removeAll())")





var grade : String? //allocate some value
grade = "A"
let finalGrade = grade ?? "F"




